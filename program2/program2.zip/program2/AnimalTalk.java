// Name: Nico Rojas
// Instructor: Krumpe
// CSE 174-F
// Date: 9/1/2015
// Filename: AnimalTalk.java
// Description: Output an animal speaking a greeting.

public class AnimalTalk {
   
   public static void main(String[] args) { 
      
      System.out.println("  ______      ______      ");
      System.out.println(" / How's \\   /. .    \\_/| ");
      System.out.println("|  Your   > | ___     _ | ");
      System.out.println(" \\ Day?  /   \\____v__/ \\| ");
      System.out.println("   ------                 ");
   }
}
