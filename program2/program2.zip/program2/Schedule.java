// Name: Nico Rojas
// Instructor: Krumpe
// CSE 174-F
// Date: 9/1/2015
// Filename: Schedule.java
// Description: Output list of my Miami courses.

public class Schedule {
   
   public static void main(String[] args) { 
      
      System.out.println("Course       Meeting");
      System.out.println("-----------------------------------------");
      System.out.println("IMS 333      MW    8:30-9:50a");
      System.out.println("CSE 174      MW    1:00-1:55p, R 2:00-3:50p");
      System.out.println("MTH 151      MTWR  4:00-5:10p");
      System.out.println("BUS 101      TR    8:30-9:50a");
      System.out.println("CEC 101      TR    1:00-1:55p");
   }
}
